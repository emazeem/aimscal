<?php include('layout/master1.php') ?>
<div class="main-banner" id="top">
    </div>
        <div class="section events" id="events">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="section-heading">
                            <h4 class="mt-2">Metrology Consultancy & Training</h4>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-6">
                        <div class="item bg-light">
                            <div class="row">
                                <div class="col-lg-3">
                                    <div class="image ">
                                        <img src="" alt="" />
                                    </div>
                                </div>
                                <div class="col-lg-9">
                                    <ul>
                                        <li>► AIMS management have set up number of calibration laboratories starting from conception to design and development,  procurement of calibration standards, training of staff, development and implementation of ISO / IEC 17025: 2005 and development of calibration business through systematic marketing strategies.
                                            <br>
                                            ► We can offer partial or full fledged consultancy to the potential clients for setting up, operation and accreditation of commercial or in-house calibration set up.
                                        </li>
                                        <li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php include('layout/master2.php') ?>