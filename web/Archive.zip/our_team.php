<?php include('layout/master1.php') ?>

    <div class="main-banner" id="top"></div>
    <?php include('components/team-details.php') ?>
<?php include('layout/master2.php') ?>