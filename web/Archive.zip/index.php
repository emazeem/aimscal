<?php include('layout/master1.php') ?>
<?php include('components/gallery.php') ?>
<?php include('components/services.php') ?>
<?php include('components/about-us.php') ?>
<?php include('components/facts.php') ?>
<?php include('components/team.php') ?>
<?php include('components/contact-us.php') ?>
<?php include('layout/master2.php') ?>
