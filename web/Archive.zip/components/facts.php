<div class="section fun-facts">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="wrapper">
                    <div class="row">
                        <div class="col-lg-3 col-md-6">
                            <div class="counter">
                                <h2 class="timer count-title count-number" data-to="1000" data-speed="1000"></h2>
                                <p class="count-text">Customers</p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="counter">
                                <h2 class="timer count-title count-number" data-to="40" data-speed="1000"></h2>
                                <p class="count-text">Parameters</p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="counter">
                                <h2 class="timer count-title count-number" data-to="500" data-speed="1000"></h2>
                                <p class="count-text">Trainings</p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="counter end">
                                <h2 class="timer count-title count-number" data-to="20" data-speed="1000"></h2>
                                <p class="count-text">Years Experience</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
