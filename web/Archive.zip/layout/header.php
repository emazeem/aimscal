<?php
$services=[
    array('title'=>'Calibration Services','description'=>'Accredited and Traceable to ensure measurement comparability.','icon'=>'calibration.png'),
    array('title'=>'Inspection, Testing & Calibration Services','description'=>'Accredited and Traceable to ensure measurement comparability.','icon'=>'inspection.png'),
    array('title'=>'Metrology Consultancy & Training','description'=>'Prepare you to meet international standards and maintain in-house capability for calibration.','icon'=>'training.png'),
    array('title'=>'QMS Consultancy','description'=>'Prepare you to meet international standards and maintain in-house capability for calibration.','icon'=>'training.png'),
    array('title'=>'Electrical Appliance Safety Testing Services','description'=>'Ensure electrical safety from electrical appliances and reliability of medical diagnostics.','icon'=>'calibration.png'),
    array('title'=>'Bio Medical Equipment Calibration, Inspection & Testing Services','description'=>'','icon'=>'calibration.png'),
    array('title'=>'Lifting Equipment Inspection Services','description'=>'Accredited and Traceable to ensure measurement comparability.','icon'=>'lifting.png'),
    array('title'=>'Non-Destructive Inspection Services','description'=>'Avoid costly failures and industrial accidents.','icon'=>'calibration.png'),
    array('title'=>'Storage Tanks Calibration Services','description'=>'Accredited and Traceable to ensure measurement comparability.','icon'=>'tank.png'),
    array('title'=>'Cathodic Protection System Installation and Servicing','description'=>'Increase service life of you buried assets.','icon'=>'electrolysis.png'),
];
?>

<header class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <a href="index.html" class="logo">
                        <img src="/public/assets/images/AIMS.png" style="width: 70px;margin-top:-10px"  alt="">
                    </a>
                    <ul class="nav">
                        <li class="scroll-to-section"><a class="{{Route::currentRouteName()=='home'?'active':''}}" href="index.php">Home</a></li>
                        <li class="">
                            <a class="{{Route::currentRouteName()==''?'active':''}} " href="#" id="servicesDropdown" >Services <i class="fa fa-angle-down" style="font-size: 10px"></i></a>
                            <div class="dropdown-menu" aria-labelledby="servicesDropdown">
                                <?php foreach($services as $service) {?>
                                    <a class="dropdown-item" href="{{route('service',['type'=>Str::slug($service['title'])])}}"><?php echo $service['title'] ?></a>
                                <?php } ?>
                            </div>
                        </li>
                        <li class="scroll-to-section"><a class="" href="our_team.php">Team</a></li>
                        <li class="scroll-to-section"><a class="" href="about_us.php">About Us</a></li>
                        <li class="scroll-to-section"><a class="" href='contact_us.php'>Contact Us</a></li>
                        <li class="scroll-to-section main-button"><a class="" href="generate-requests.php">Request a Quote</a></li>
                    </ul>
                    <a class="menu-trigger">
                        <span>Menu</span>
                    </a>
                    <!-- ***** Menu End ***** -->
                </nav>
            </div>
        </div>
    </div>
</header>
